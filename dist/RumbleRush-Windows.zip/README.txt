RUMBLE RUSH

Keep RumbleRush.exe and RumbleRush.pck in the same folder, then double-click RumbleRush.exe.

If Windows shows 'Windows protected your PC', click 'More info' then 'Run anyway'.
The game is not code-signed, which is why Windows is cautious about it.
